import axios from 'axios';

export const api = {
  getProducts: () => axios.get('/api/v1/products'),
  createOrder: (data: any) => axios.post('/api/v1/orders', data),
};
