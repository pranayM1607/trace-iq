import React from 'react';
import { ProductList } from './components/ProductList';
import { api } from './api/client';

export function App() {
  return <ProductList />;
}
