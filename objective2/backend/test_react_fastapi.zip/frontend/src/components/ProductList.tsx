import React from 'react';
import { api } from '../api/client';

export function ProductList() {
  return <div>Product Catalog</div>;
}
