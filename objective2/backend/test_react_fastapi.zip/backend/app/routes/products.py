from fastapi import APIRouter
from ..db.session import get_db

router = APIRouter()

@router.get('/api/v1/products')
def list_products():
    return [{"id": 1, "name": "Laptop", "price": 999}]
