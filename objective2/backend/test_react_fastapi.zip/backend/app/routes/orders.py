from fastapi import APIRouter
from ..db.session import get_db
from ..services.payment import process_checkout

router = APIRouter()

@router.post('/api/v1/orders')
def create_order(order_data: dict):
    return process_checkout(order_data)
