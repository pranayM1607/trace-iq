import psycopg2

def get_db():
    return psycopg2.connect("postgresql://user:pass@localhost:5432/retail_db")
