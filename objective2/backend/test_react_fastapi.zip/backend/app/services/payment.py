import requests
from ..db.session import get_db

def process_checkout(order_data):
    return {"status": "success", "order_id": 101}
