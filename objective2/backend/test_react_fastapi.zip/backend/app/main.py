from fastapi import FastAPI
from .routes.products import router as product_router
from .routes.orders import router as order_router
from .db.session import get_db

app = FastAPI(title="Retail API")
app.include_router(product_router)
app.include_router(order_router)
