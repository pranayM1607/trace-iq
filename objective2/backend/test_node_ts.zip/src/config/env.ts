import dotenv from 'dotenv';
dotenv.config();
export const config = {
  port: process.env.PORT || 3000,
  dbUrl: process.env.DATABASE_URL || 'postgresql://localhost:5432/test'
};
