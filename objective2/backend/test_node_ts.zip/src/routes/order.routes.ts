import { Router } from 'express';
import { OrderService } from '../services/order.service';

export const orderRouter = Router();
const orderService = new OrderService();

orderRouter.get('/', (req, res) => {
  res.json(orderService.listOrders());
});
