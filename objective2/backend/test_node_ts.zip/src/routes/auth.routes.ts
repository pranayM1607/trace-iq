import { Router } from 'express';
import { AuthService } from '../services/auth.service';

export const authRouter = Router();
const authService = new AuthService();

authRouter.post('/login', (req, res) => {
  res.json(authService.login(req.body));
});
