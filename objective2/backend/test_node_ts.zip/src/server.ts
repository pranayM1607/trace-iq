import express from 'express';
import { authRouter } from './routes/auth.routes';
import { orderRouter } from './routes/order.routes';
import { config } from './config/env';

const app = express();
app.use('/auth', authRouter);
app.use('/orders', orderRouter);
