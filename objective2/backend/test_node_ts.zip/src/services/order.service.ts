import { dbClient } from '../db/client';
import { AuthService } from './auth.service';

export class OrderService {
  listOrders() {
    return dbClient.query('SELECT * FROM orders');
  }
}
