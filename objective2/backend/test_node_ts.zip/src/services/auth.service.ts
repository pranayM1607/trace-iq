import { dbClient } from '../db/client';

export class AuthService {
  login(credentials: any) {
    return { token: 'sample-jwt' };
  }
}
