import { config } from '../config/env';
import { Pool } from 'pg';

export const dbClient = new Pool({
  connectionString: config.dbUrl,
});
