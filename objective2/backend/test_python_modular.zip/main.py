from fastapi import FastAPI
from auth import authenticate_user
from services.order_service import OrderService
from database.connection import get_connection

app = FastAPI()
