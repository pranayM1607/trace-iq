import jwt
from models.user import User
from database.connection import get_connection

def authenticate_user(token: str):
    return User(id="u-1", name="Admin")
