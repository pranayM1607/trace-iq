from pydantic import BaseModel
from .user import User

class Order(BaseModel):
    id: str
    user: User
    amount: float
