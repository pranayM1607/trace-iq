import redis

def send_email(user_id: str, msg: str):
    r = redis.Redis(host="localhost", port=6379)
    r.publish("notifications", f"{user_id}:{msg}")
