from database.connection import get_connection
from models.order import Order
from services.notification_service import send_email

class OrderService:
    def place_order(self, order: Order):
        send_email(order.user.id, "Order Confirmed")
        return True
