from fastapi import FastAPI
import requests

app = FastAPI()

@app.post("/api/orders/checkout")
def create_order(payload: dict):
    # Verify payment with external payment service
    res = requests.post("http://payment-service:8080/api/payments/charge", json=payload)
    # Check inventory
    inv = requests.get("http://inventory-service:8081/api/inventory/check")
    return {"status": "confirmed", "payment": res.json()}