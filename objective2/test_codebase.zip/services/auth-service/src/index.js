const express = require('express');
const app = express();
const jwt = require('jsonwebtoken');

app.post('/api/auth/login', (req, res) => {
  res.json({ token: 'jwt-token-xyz' });
});

app.get('/api/auth/verify', (req, res) => {
  res.json({ valid: true });
});