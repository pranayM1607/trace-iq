const express = require('express');
const app = express();

app.post('/api/payments/charge', (req, res) => {
  res.json({ id: 'ch_123', status: 'succeeded' });
});