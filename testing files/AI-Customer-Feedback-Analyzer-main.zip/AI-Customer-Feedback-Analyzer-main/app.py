import streamlit as st
import pandas as pd
import google.generativeai as genai
from dotenv import load_dotenv
import plotly.express as px
import os

# ==================================
# CONFIGURATION
# ==================================

load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

st.set_page_config(
    page_title="AI Customer Feedback Analyzer",
    page_icon="📊",
    layout="wide"
)

# ==================================
# GEMINI SETUP
# ==================================

if not GOOGLE_API_KEY:
    st.error(
        "Gemini API Key not found. Add GOOGLE_API_KEY to .env"
    )
    st.stop()

genai.configure(api_key=GOOGLE_API_KEY)

# ==================================
# TITLE
# ==================================

st.title("📊 AI Customer Feedback Analyzer")

st.write(
    "Upload customer reviews and feedback data to uncover sentiment, complaints, feature requests, and actionable business insights."
)

# ==================================
# FILE UPLOAD
# ==================================

uploaded_file = st.file_uploader(
    "Upload Reviews CSV",
    type=["csv"]
)

# ==================================
# PROCESS FILE
# ==================================

if uploaded_file:

    try:

        df = pd.read_csv(uploaded_file)

        required_columns = [
            "content",
            "score",
            "appId"
        ]

        missing_cols = [
            col for col in required_columns
            if col not in df.columns
        ]

        if missing_cols:
            st.error(
                f"Missing columns: {missing_cols}"
            )
            st.stop()

        # ==================================
        # CLEAN DATA
        # ==================================

        df = df.dropna(
            subset=["content"]
        )

        df["content"] = (
            df["content"]
            .astype(str)
            .str.strip()
        )

        df = df[
            df["content"] != ""
        ]

        # ==================================
        # DASHBOARD
        # ==================================

        total_reviews = len(df)

        positive_reviews = len(
            df[df["score"] >= 4]
        )

        neutral_reviews = len(
            df[df["score"] == 3]
        )

        negative_reviews = len(
            df[df["score"] <= 2]
        )

        total_apps = df["appId"].nunique()

        st.success(
            "Dataset Loaded Successfully!"
        )

        c1, c2, c3, c4, c5 = st.columns(5)

        c1.metric(
            "📊 Reviews",
            total_reviews
        )

        c2.metric(
            "😊 Positive",
            positive_reviews
        )

        c3.metric(
            "😐 Neutral",
            neutral_reviews
        )

        c4.metric(
            "☹️ Negative",
            negative_reviews
        )

        c5.metric(
            "📱 Apps",
            total_apps
        )

        st.divider()

        # ==================================
        # APP SELECTOR
        # ==================================

        app_list = sorted(
            df["appId"].unique()
        )

        selected_app = st.selectbox(
            "Select App",
            app_list
        )

        app_df = df[
            df["appId"] == selected_app
        ]

        st.info(
            f"Selected App Reviews: {len(app_df)}"
        )

        st.subheader(
            "📄 Sample Reviews"
        )

        st.dataframe(
            app_df[
                ["content", "score"]
            ].head(20)
        )

        st.divider()

        # ==================================
        # CHARTS
        # ==================================

        st.subheader(
            "📈 Analytics Dashboard"
        )

        sentiment_counts = pd.DataFrame(
            {
                "Sentiment": [
                    "Positive",
                    "Neutral",
                    "Negative"
                ],
                "Count": [
                    len(
                        app_df[
                            app_df["score"] >= 4
                        ]
                    ),
                    len(
                        app_df[
                            app_df["score"] == 3
                        ]
                    ),
                    len(
                        app_df[
                            app_df["score"] <= 2
                        ]
                    )
                ]
            }
        )

        pie_chart = px.pie(
            sentiment_counts,
            names="Sentiment",
            values="Count",
            title="Sentiment Distribution"
        )

        st.plotly_chart(
            pie_chart,
            use_container_width=True
        )

        rating_chart = px.bar(
            app_df["score"]
            .value_counts()
            .sort_index()
            .reset_index(),
            x="score",
            y="count",
            title="Rating Distribution"
        )

        st.plotly_chart(
            rating_chart,
            use_container_width=True
        )

        st.divider()

        # ==================================
        # AI ANALYSIS
        # ==================================

        if st.button(
            "🚀 Generate AI Insights"
        ):

            with st.spinner(
                "Analyzing reviews..."
            ):

                sample_reviews = (
                    app_df["content"]
                    .dropna()
                    .sample(
                        min(
                            1000,
                            len(app_df)
                        ),
                        random_state=42
                    )
                    .tolist()
                )

                reviews_text = "\n".join(
                    sample_reviews
                )

                model = genai.GenerativeModel(
                    "gemini-2.5-flash"
                )

                prompt = f"""
You are a Senior Product Manager.

Analyze these customer reviews.

Provide:

# Executive Summary

Summarize overall customer sentiment.

# Top Customer Complaints

List major issues.

# Most Requested Features

List requested features.

# Product Recommendations

Provide actionable recommendations.

# Priority Fixes

Suggest what should be fixed first.

Reviews:

{reviews_text}
"""

                response = (
                    model.generate_content(
                        prompt
                    )
                )

            st.success(
                "Analysis Complete!"
            )

            st.subheader(
                "🧠 AI Product Insights"
            )

            st.markdown(
                response.text
            )

            st.download_button(
                label="📥 Download AI Report",
                data=response.text,
                file_name=f"{selected_app}_report.txt",
                mime="text/plain"
            )

        st.divider()

        # ==================================
        # DOWNLOAD CLEAN DATA
        # ==================================

        csv_data = app_df.to_csv(
            index=False
        )

        st.download_button(
            label="📥 Download App Reviews CSV",
            data=csv_data,
            file_name=f"{selected_app}_reviews.csv",
            mime="text/csv"
        )

    except Exception as e:

        st.error(
            f"Error: {str(e)}"
        )