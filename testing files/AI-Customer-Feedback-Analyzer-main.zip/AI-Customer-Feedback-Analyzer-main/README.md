# 📊 AI Customer Feedback Analyzer

## Overview

AI Customer Feedback Analyzer is an AI-powered analytics platform that helps businesses and product teams extract actionable insights from customer reviews and feedback.

The application uses Google Gemini 2.5 Flash to analyze large-scale customer review datasets and generate business-focused insights such as customer sentiment, complaints, feature requests, recommendations, and priority improvements.

The platform also provides interactive analytics dashboards, sentiment visualizations, and app-specific review analysis.

---

## Features

### 📂 CSV Review Upload

* Upload customer review datasets in CSV format
* Supports large review datasets (12,000+ reviews)
* Automatic data validation and cleaning

### 📊 Analytics Dashboard

View key metrics including:

* Total Reviews
* Positive Reviews
* Neutral Reviews
* Negative Reviews
* Total Applications

### 📈 Interactive Visualizations

* Sentiment Distribution Pie Chart
* Rating Distribution Bar Chart
* App-specific review analysis

### 🤖 AI-Powered Insights

Generate:

* Executive Summary
* Top Customer Complaints
* Most Requested Features
* Product Recommendations
* Priority Fixes

using Google Gemini 2.5 Flash.

### 📥 Export Support

* Download AI-generated reports
* Download processed review datasets

---

## Dataset

This project was tested using the Google Play Store Reviews dataset containing:

* 12,495+ customer reviews
* Multiple mobile applications
* User ratings from 1 to 5
* Real-world customer feedback

Dataset columns used:

| Column  | Description            |
| ------- | ---------------------- |
| content | Customer review text   |
| score   | User rating (1–5)      |
| appId   | Application identifier |

---

## Screenshots

### Home Dashboard

![Home Dashboard](screenshots/home_dashboard.png)

### App Selection

![App Selection](screenshots/app_selection.png)

### Analytics Dashboard

![Analytics Dashboard](screenshots/analytics_dashboard.png)

### AI Insights - Part 1

![AI Insights 1](screenshots/ai_insights_1.png)

### AI Insights - Part 2

![AI Insights 2](screenshots/ai_insights_2.png)

### AI Insights - Part 3

![AI Insights 3](screenshots/ai_insights_3.png)

### AI Insights - Part 4

![AI Insights 4](screenshots/ai_insights_4.png)

---

## Technology Stack

### Frontend

* Streamlit

### Backend

* Python

### AI Model

* Google Gemini 2.5 Flash

### Data Processing

* Pandas

### Visualization

* Plotly

### Environment Management

* Python Dotenv

---

## Project Workflow

1. Upload customer review dataset.
2. Clean and process review data.
3. Calculate sentiment metrics using ratings.
4. Select a specific application.
5. Generate analytics visualizations.
6. Sample reviews for AI analysis.
7. Generate business insights using Gemini.
8. Download reports and processed data.

---

## Installation

### Clone Repository

```bash
git clone https://github.com/your-username/ai-customer-feedback-analyzer.git

cd ai-customer-feedback-analyzer
```

### Create Virtual Environment

```bash
python -m venv venv
```

### Activate Environment

Windows:

```bash
venv\Scripts\activate
```

Linux / Mac:

```bash
source venv/bin/activate
```

### Install Dependencies

```bash
pip install -r requirements.txt
```

### Create Environment File

Create a file named `.env`

```env
GOOGLE_API_KEY=YOUR_GEMINI_API_KEY
```

### Run Application

```bash
streamlit run app.py
```

---

## Project Structure

```text
ai-customer-feedback-analyzer/

├── app.py
├── README.md
├── requirements.txt
├── .gitignore
├── .env.example

├── screenshots/
│   ├── home_dashboard.png
│   ├── app_selection.png
│   ├── analytics_dashboard.png
│   ├── ai_insights_1.png
│   ├── ai_insights_2.png
│   ├── ai_insights_3.png
│   └── ai_insights_4.png
```

---

## Future Improvements

* PDF Report Export
* Trend Analysis
* Topic Modeling
* Customer Segmentation
* Multi-file Comparison
* Real-Time Feedback Monitoring
* Voice of Customer Analytics
* Sentiment Trend Tracking
* Automated Product Roadmap Suggestions

---

## Learning Outcomes

This project demonstrates:

* Generative AI Integration
* Customer Feedback Analytics
* Product Management Thinking
* Data Visualization
* Prompt Engineering
* Streamlit Development
* Business Insight Generation
* AI-Powered Decision Support Systems

---

## Author

**Pranay M**

Computer Science and Business Systems Student

Interested in:

* Product Management
* Generative AI Applications
* Customer Analytics
* AI Product Development
