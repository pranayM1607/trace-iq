package in.curdjava.CurdJavaDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.jdbc.autoconfigure.DataSourceAutoConfiguration;

@SpringBootApplication()
public class CurdJavaDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurdJavaDemoApplication.class, args);
		System.out.println("Client is Allowed to send the request");
	}

}
