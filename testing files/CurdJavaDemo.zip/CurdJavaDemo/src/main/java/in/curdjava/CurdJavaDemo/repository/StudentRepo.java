package in.curdjava.CurdJavaDemo.repository;

import in.curdjava.CurdJavaDemo.entity.Student;
import org.springframework.stereotype.Component;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;


public interface StudentRepo extends JpaRepository<Student , Long>{
    //Get By id
    Optional<Student> findByIdAndDeletedFalse(Long id);
    //Get All
    List<Student> findAllByDeletedIsFalse();

}
