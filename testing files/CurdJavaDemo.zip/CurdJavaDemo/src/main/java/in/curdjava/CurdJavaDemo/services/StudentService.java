package in.curdjava.CurdJavaDemo.services;

import in.curdjava.CurdJavaDemo.entity.Student;
import in.curdjava.CurdJavaDemo.repository.StudentRepo;
import jakarta.persistence.metamodel.SingularAttribute;
import org.springframework.data.jpa.domain.AbstractPersistable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService
{

    private StudentRepo studentRepo;
    public StudentService(StudentRepo studentRepo)
    {

        this.studentRepo = studentRepo;
    }



    public Student StudentCreate(Student studentReq){
        studentReq.setDeleted(false);
        Student studentservice = studentRepo.save(studentReq);
        return studentservice;
    }

    public Student StudentGet(Long id)
    {
        Optional<Student> studentOptional = studentRepo.findByIdAndDeletedFalse(id);
        return studentOptional.orElse(null);
    }

    //GetAll
    public List<Student> StudentGetAll(Student student)
    {
        List<Student> studentOptionalAll = studentRepo.findAllByDeletedIsFalse();
        return studentOptionalAll;
    }

    //Delete by Id
    public void StudentDeleteId(Long id)
    {
        studentRepo.deleteById(id);
    }


    public void StudentDeleteAll() {
        studentRepo.deleteAll();
    }

    public Student StudentsUpdate(Long id, Student student) {
        Optional<Student> CheckExist = studentRepo.findById(id);
        if(CheckExist.isEmpty()) {
            return null;
        }
        Student StudentUpdateBody = CheckExist.get();
        StudentUpdateBody.setName(student.getName());
        StudentUpdateBody.setAge(student.getAge());
        StudentUpdateBody.setEmail(student.getEmail());
        StudentUpdateBody.setRollNo(student.getRollNo());
        student.setDeleted(false);

        return studentRepo.save(StudentUpdateBody);
    }

    public Student StudentSoftDelete(Long id)
    {
        Optional<Student> CheckExist = studentRepo.findById(id);
        if(CheckExist.isPresent())
        {
            Student  studentSoftDelete = CheckExist.get();
            studentSoftDelete.setDeleted(true);
            studentRepo.save(studentSoftDelete);
            return studentSoftDelete;
        }
        return null;

    }
}
