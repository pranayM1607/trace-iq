package in.curdjava.CurdJavaDemo.controller;

import in.curdjava.CurdJavaDemo.entity.Student;
import in.curdjava.CurdJavaDemo.services.StudentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@RestController
@RequestMapping("/api/student")
public class StudentController {

    private StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @PostMapping("/create")
    public ResponseEntity<Student> StudentCreate(@RequestBody Student student) {
        Student studentcontrol = studentService.StudentCreate(student);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(studentcontrol);
    }
    // get through id
      @GetMapping("/get")
        public ResponseEntity<Student> studentGet(@RequestParam Long id)
        {
            Student studentcontrolget = studentService.StudentGet(id);
            if(studentcontrolget == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }
            return ResponseEntity.status(HttpStatus.OK).body(studentcontrolget);
        }
        //Get ALL
        @GetMapping("/getAll")
    public ResponseEntity<List<Student>> studentGetAll(Student student)
    {
       List<Student> studentgetall = studentService.StudentGetAll(student);
        return ResponseEntity.ok(studentgetall);
    }

    //Delete by ID
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Student> StudentDelete(@PathVariable Long id)
    {
        studentService.StudentDeleteId(id);
        System.out.println("The student is deleted" + id);
        return ResponseEntity.status(HttpStatus.OK).body(null);
    }

    @DeleteMapping("/deleteall")
    public ResponseEntity<Student> StudentDelete()
    {
        studentService.StudentDeleteAll();
        System.out.println("The student is deleted" + id);
        return ResponseEntity.status(HttpStatus.OK).body(null);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Student> StudentUpdate(@PathVariable Long id,@RequestBody Student student)
    {
        Student studentupdate = studentService.StudentsUpdate(id, student);
        if(studentupdate == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        return ResponseEntity.status(HttpStatus.OK).body(studentupdate);
    }

    //Soft-Delete
    @PatchMapping("/soft-delete/{id}")
    public ResponseEntity<Student> StudentSDelete(@PathVariable Long id)
    {
        Student studentupdate = studentService.StudentSoftDelete(id);
        if(studentupdate == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        return ResponseEntity.status(HttpStatus.OK).body(studentupdate);
    }





}