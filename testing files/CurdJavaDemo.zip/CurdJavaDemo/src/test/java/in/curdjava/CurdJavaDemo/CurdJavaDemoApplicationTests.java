package in.curdjava.CurdJavaDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurdJavaDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
