# 📚 RAG Research Assistant

**Version:** 1.0

A Retrieval-Augmented Generation (RAG) application that allows users to upload PDF documents, create vector embeddings, perform semantic search, and ask questions about document content using Google Gemini.

---

## 🚀 Features

* Upload PDF documents
* Extract text from PDFs
* Split text into manageable chunks
* Generate embeddings using Google Gemini
* Store embeddings in a FAISS vector database
* Semantic document retrieval
* Ask natural language questions about uploaded PDFs
* AI-generated answers based on retrieved context
* Streamlit-based interactive user interface
* Handles large PDFs while staying within API limits

---

## 🛠️ Tech Stack

### Frontend

* Streamlit

### Backend

* Python

### AI & RAG

* Google Gemini
* LangChain
* FAISS

### PDF Processing

* PyPDF

### Environment Management

* Python Dotenv

---

## 📂 Project Structure

```text
RAG-Research-Assistant/
│
├── app.py
├── requirements.txt
├── README.md
│
└── screenshots/
    ├── home.png
    ├── pdf_uploaded.png
    └── answer_demo.png
```

---

## 📸 Screenshots

### Home Screen

![Home Screen](screenshots/home.png)

### PDF Upload & Processing

![PDF Upload](screenshots/pdf_uploaded.png)

### Question Answering Demo

![Answer Demo](screenshots/answer_demo.png)

---

## ⚙️ Installation

### 1. Clone Repository

```bash
git clone https://github.com/your-username/RAG-Research-Assistant.git
cd RAG-Research-Assistant
```

### 2. Create Virtual Environment

```bash
python -m venv venv
```

Activate:

#### Windows

```bash
venv\Scripts\activate
```

#### Linux / macOS

```bash
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure API Key

Create a `.env` file:

```env
GOOGLE_API_KEY=YOUR_GEMINI_API_KEY
```

Get your Gemini API key from Google AI Studio.

### 5. Run Application

```bash
streamlit run app.py
```

---

## 🔄 How It Works

1. User uploads a PDF.
2. Text is extracted from the document.
3. Text is split into chunks.
4. Gemini Embeddings convert chunks into vectors.
5. FAISS stores vectors for similarity search.
6. User asks a question.
7. Relevant chunks are retrieved.
8. Gemini generates an answer using retrieved context.

---

## 🎯 Example Queries

* Summarize this document in 5 points.
* What are the main findings of this paper?
* Explain the methodology used in the document.
* List the key conclusions.
* What recommendations are provided?

---

## 📈 Future Improvements

* Multiple PDF support
* Chat history
* Conversation memory
* Source citations with page numbers
* PDF export of answers
* Deployment to Streamlit Cloud

---

## 👨‍💻 Author

**Pranay M**

Computer Science & Business Systems Student

Interested in:

* Product Management
* Data Analytics
* Generative AI Applications

---

## ⭐ Project Highlights

* Built an end-to-end Retrieval-Augmented Generation (RAG) pipeline.
* Integrated Google Gemini for embeddings and answer generation.
* Implemented semantic search using FAISS vector database.
* Developed an interactive Streamlit interface for document-based Q&A.
* Applied modern GenAI and NLP concepts to solve real-world document retrieval problems.

---

## 📌 Project Status

✅ Version 1.0 (MVP Completed)

Current Capabilities:

* Single PDF Upload
* Semantic Search
* Question Answering using Gemini
* FAISS Vector Storage
* Streamlit Interface

Planned for Future Versions:

* Multi-PDF Support
* Chat Memory
* Citation Support
* Cloud Deployment
