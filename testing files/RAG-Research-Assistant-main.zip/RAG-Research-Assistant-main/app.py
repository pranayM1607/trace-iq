import streamlit as st
from pypdf import PdfReader
from dotenv import load_dotenv
import os

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import (
    GoogleGenerativeAIEmbeddings,
    ChatGoogleGenerativeAI
)
from langchain_community.vectorstores import FAISS

# =========================
# Load Environment Variables
# =========================

load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

# =========================
# Page Config
# =========================

st.set_page_config(
    page_title="RAG Research Assistant",
    page_icon="📚",
    layout="wide"
)

st.title("📚 RAG Research Assistant")
st.write("Upload a PDF and ask questions about it.")

# =========================
# Upload PDF
# =========================

uploaded_file = st.file_uploader(
    "Upload a PDF",
    type=["pdf"]
)

if uploaded_file:

    # =========================
    # Read PDF
    # =========================

    reader = PdfReader(uploaded_file)

    text = ""

    for page in reader.pages:
        page_text = page.extract_text()

        if page_text:
            text += page_text

    st.success("PDF Read Successfully!")

    # =========================
    # Split Text
    # =========================

    splitter = RecursiveCharacterTextSplitter(     
        chunk_size=10000,
        chunk_overlap=100
    )

    chunks = splitter.split_text(text)

    MAX_CHUNKS = 30

    if len(chunks) > MAX_CHUNKS:

        st.warning(
            f"Large PDF detected ({len(chunks)} chunks). "
            f"Processing only first {MAX_CHUNKS} chunks to stay within API limits."
        )

        chunks = chunks[:MAX_CHUNKS]

    st.info(f"Total Chunks Created: {len(chunks)}")

    # =========================
    # Create Embeddings
    # =========================

    try:

        embeddings = GoogleGenerativeAIEmbeddings(
            model="models/gemini-embedding-001",
            google_api_key=GOOGLE_API_KEY
        )

        vector_store = FAISS.from_texts(
            texts=chunks,
            embedding=embeddings
        )

        st.success("✅ Vector Database Created!")

    except Exception:

        st.error(
            "❌ Gemini embedding quota exceeded.\n\n"
            "Wait a few minutes and try again, or upload a smaller PDF."
        )

        st.stop()

    # =========================
    # Ask Questions
    # =========================

    st.divider()

    st.subheader("Ask Questions About Your PDF")

    user_question = st.text_area(
        "Enter your question",
        placeholder="Example: Summarize this document in 5 points",
        height=120
    )

    ask_button = st.button("🔍 Get Answer")

    if ask_button:

        if not user_question.strip():
            st.warning("Please enter a question.")
            st.stop()

        try:

            docs = vector_store.similarity_search(
                user_question,
                k=3
            )

            context = "\n\n".join(
                [doc.page_content for doc in docs]
            )

            prompt = f"""
You are a helpful research assistant.

Answer ONLY using the context below.

Context:
{context}

Question:
{user_question}

Answer:
"""

            llm = ChatGoogleGenerativeAI(
                model="gemini-2.5-flash",
                google_api_key=GOOGLE_API_KEY,
                temperature=0.2
            )

            response = llm.invoke(prompt)

            st.subheader("Answer")
            st.write(response.content)

            # =========================
            # Retrieved Chunks
            # =========================

            with st.expander("Retrieved Chunks"):

                for i, doc in enumerate(docs, start=1):

                    st.markdown(f"### Chunk {i}")
                    st.write(doc.page_content)
                    st.divider()

        except Exception as e:

            st.error(f"Error generating answer: {str(e)}")

    # =========================
    # Preview First Chunk
    # =========================

    with st.expander("Preview First Chunk"):

        if len(chunks) > 0:
            st.write(chunks[0])